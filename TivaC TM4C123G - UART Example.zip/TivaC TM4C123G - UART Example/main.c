/*
 * UART Example show how to turn on/of led using terminal working with 9600bps baud rate
 *
 * Author @ Mohamed ELnahas
 * Date : 9/3/2016
 */

void ISRGPIOA(void){



}
volatile unsigned long delay;

char read();
void printChar(char);
void printString(char *);



#define SYSCTL_REG		 (*((volatile unsigned long  *)0X400FE108))  // SYSTEM CLK
#define RCGCUART		 (*((volatile unsigned long  *)0x400FE618))  // UART CLK


// PORT A
#define GPIO_PORTA_DATA  (*((volatile unsigned long  *)0X40004000))
#define GPIO_PORTA_LOCK  (*((volatile unsigned long  *)0X40004520))
#define GPIO_PORTA_CR    (*((volatile unsigned long  *)0x40004524))
#define GPIO_PORTA_AFSEL (*((volatile unsigned long  *)0x40004420))
#define GPIO_PORTA_PCTL  (*((volatile unsigned long  *)0x4000452C))
#define GPIO_PORTA_AMSEL (*((volatile unsigned long  *)0x40004528))
#define GPIO_PORTA_DIR   (*((volatile unsigned long  *)0x40004400))
#define GPIO_PORTA_PUR   (*((volatile unsigned long  *)0x40004510))
#define GPIO_PORTA_PDR   (*((volatile unsigned long  *)0x40004514))
#define GPIO_PORTA_EN    (*((volatile unsigned long  *)0x4000451C))

// PORT F

#define GPIO_PORTF_DATA  (*((volatile unsigned long  *)0X400253FC))
#define GPIO_PORTF_LOCK  (*((volatile unsigned long  *)0X40025520))
#define GPIO_PORTF_CR    (*((volatile unsigned long  *)0x40025524))
#define GPIO_PORTF_AFSEL (*((volatile unsigned long  *)0x40025420))
#define GPIO_PORTF_PCTL  (*((volatile unsigned long  *)0x4002552C))
#define GPIO_PORTF_AMSEL (*((volatile unsigned long  *)0x40025528))
#define GPIO_PORTF_DIR   (*((volatile unsigned long  *)0x40025400))
#define GPIO_PORTF_PUR   (*((volatile unsigned long  *)0x40025510))
#define GPIO_PORTF_PDR   (*((volatile unsigned long  *)0x40025514))
#define GPIO_PORTF_EN    (*((volatile unsigned long  *)0x4002551C))

// UART0  REGISTES
#define UART0DR 		 (*((volatile unsigned long  *)0x4000C000))
#define UART0IBRD  		 (*((volatile unsigned long  *)0x4000C024))
#define UART0FBRD  		 (*((volatile unsigned long  *)0x4000C028))
#define UART0LCRH 		 (*((volatile unsigned long  *)0x4000C02C))
#define UART0CTL 		 (*((volatile unsigned long  *)0x4000C030))
#define UART0CC 		 (*((volatile unsigned long  *)0x4000CFC8))
#define UART0FR 		 (*((volatile unsigned long  *)0x4000C018))



void GPIO_PORTA_Init()

{
				SYSCTL_REG |= (1<<0);           // set clk for PORTA
				delay = 0X00000020;				// delay for 3 cycle
				GPIO_PORTA_LOCK = 0X4C4F434B;   // put this value to unlock CR
				GPIO_PORTA_CR = 0XFF;			// open all pins to be controlled
				GPIO_PORTA_AMSEL = 0X00;		// disable analog
				GPIO_PORTA_PCTL = 0X11;			// make pins (PA0,PA1) at PORTA using AF as tx and rx
				GPIO_PORTA_AFSEL = 0X03;		// selected pins to working in AF mode
				GPIO_PORTA_EN = 0XFF;			// enable digital pins

}


void GPIO_PORTF_Init()
{
				SYSCTL_REG |= 0X00000020;
				delay = 0X00000020;
				GPIO_PORTF_LOCK = 0X4C4F434B;
				GPIO_PORTF_CR = 0X1F;
				GPIO_PORTF_AMSEL = 0X00;
				GPIO_PORTF_PCTL = 0X00;
				GPIO_PORTF_DIR = 0X0E;
				GPIO_PORTF_AFSEL = 0X00 ;
				GPIO_PORTF_PUR = 0X11;
				GPIO_PORTF_EN = 0X1F;

}

void UART0_Init()
{
				RCGCUART |= (1<<0);					// enable UART0 clk
				delay = 0X00000020;					// delay to stable CLK
				UART0CTL &= (0<<0);					// Diasble UART untill modifiy register to avoid any damage
				UART0IBRD = 104;					// set the intger part of baud rate
				UART0FBRD = 11;						// set the fraction part of buad rate
				UART0LCRH = 0X60;					// set WLEN to 8 bits  & stop bit to 0 and no parity
				UART0CC  =  0X0;					// using sysclk without devision
				UART0CTL = (1<<0)|(1<<9)|(1<<8);	// enable UART control and Tx,RX pins

}


int main(void) {
	GPIO_PORTA_Init();								// Initilation PORTA
	GPIO_PORTF_Init();								// Initilation PORTA
	UART0_Init();									// Initilation UART0

	printString("Hello World \n\r");									// welcome message
	printString("Enter r to turn led on and o to turn off\n\r");

	while(1)															//start of the code
			{
			char x =  read();											// start reading data from Serial

			switch (x)
					{
			case 'r' :													// if coming data equal 'r' on blue led

							GPIO_PORTF_DATA  |= (1<<2);					// set blue led
							printChar('r');  							// print 'r' on the terminal
						break;
			case 'o' :													// if coming data equal 'o' off blue led


							GPIO_PORTF_DATA  &= (0<<2);                 // clear blue led
							printChar('o');								// print 'o' on the terminal
						break;
					}

			}
	
}


char read()                                                             //Read FN from serial port
	{

	while(UART0FR & (1<<4));											// check of if there is data in RX register or not
	char c  =  UART0DR;													// set data to var c
	return c;															// return the data

	}


void printChar(char x )													// print char on terminal
	{
	while(UART0FR & (1<<5));											// check if TX buffer is busy or not
	UART0DR = x;														// put data  in data register and send it immediately
	}


void printString(char *string)											// print string on terminal
	{


	while(*string)														// keep in the loop untill string length
	{
		printChar(*(string++));											// send the char to print char FN then increment to the next one
	}

	}
